var list_obj=[];

function genLI(p) {
    //ต่อ String ของ 
    //<li><a href='#' onclick="show_detail('xxx')">Name<p>Phone</p></a></li>
    var str = "<li>";
    str += "<a href='#' onclick=\"show_detail('" + p.id + "')\">";
    str += p.name;
    str += "<p>" + p.phone + "</p>";
    str += "</a>";
    str += "</li>";
    return str;
}

function show_detail(id){
    //รับค่า id จาก <li><a ... onclick="show_detail('xxxxx')">...
     $.mobile.changePage("#p1", {"transition": "slide"});
     //ดึง object Person จาก list_obj ที่เก็บมาจาก JSON
    var p = list_obj[id];
    //กำหนดค่าให้กับหน้า Detail
    $("#mytitle, #pname").html(p.name);
    $("#pphone").html(p.phone);
    $("#pemail").html(p.email);
}

function updateList() {
        //ดึงข้อมูลจากไฟล์ person.json
        $.getJSON("app/person.json", function (data) {
            var lstr = "";   
            //วนดึงค่าจาก json array ที่อยู่ใน data[]
            for (var i in data) {
                // เก็บค่า data[i] ไว้ใน array เพื่อเอาไว้ใช้ในหน้า detail
                list_obj[data[i].id]=data[i];
                //สั่งให้สร้างแท็ก <li>...</li> แล้วมาต่อ String
                lstr += genLI(data[i]);
            }
        
            $("#mylist").html(lstr);
            $("#mylist").listview("refresh");
        });
}

function init() {
    //เรียกให้ update listview
    updateList();
    $("#backBt").click(function () {
        $.mobile.changePage("#main", {"transition": "slide", "reverse": "true"});
    });
}

//same as $(document).ready(init);
$(init);